<?php
/**
 * Copyright © 2009-2014 Rhizome Networks LTD All rights reserved.
 *
 * Created by IntelliJ IDEA.
 * User: Tomer Schilman
 * Date: 10/11/14
 * Time: 15:05
 */

/**
 * Plugin Name: CG Button
 * Plugin URI: http://www.contentglass.com/wordpress-plugin-help
 * Description: Add the CG Button to your Wordpress site
 * Version: 0.1
 * Author: Rhizome Networks
 * Author URI: http://www.contentglass.com
 * License:
 */

require( 'CG-Button-init.php' );






